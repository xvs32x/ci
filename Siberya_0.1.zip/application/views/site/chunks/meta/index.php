<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?= Meta::get('description')?>">
<meta name="keywords" content="<?= Meta::get('keywords')?>">
<meta name="author" content="nsv">
<title><?= Meta::get('title')?></title>