		</div>
		<div class="footer">
			<div class="container">
				<div class="row">
					<div class="col-sm-6 col-xs-6">
						<p style="margin-top: 20px;" class="text-muted"><b>CMS Сибирь</b></p>
					</div>
					<div class="col-sm-6 col-xs-6">
						<p style="margin-top: 20px;" class="text-muted text-right"><?= date('D.d.m.Y')?></p>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>