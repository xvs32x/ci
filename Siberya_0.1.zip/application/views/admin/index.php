<?= $this->load->view('admin/chunks/header')?>
<?= $this->load->view('admin/chunks/menu')?>
<div class="row content">

</div>
<?= $this->load->view('admin/chunks/footer')?>