</div>
<div class="footer">
	<div class="container">
		<div class="row">
			<div class="col-sm-6 col-xs-6">
				<p style="margin-top: 20px;" class="text-muted"><a href="mailto:x64vs32x@mail.ru">Поддержка сайта</a></p>
			</div>
			<div class="col-sm-6 col-xs-6">
				<p style="margin-top: 20px;" class="text-muted text-right">Время сервера: <?= date('D.d.m.Y')?></p>
			</div>
		</div>
	</div>
</div>
	</body>
</html>
<?php //echo $this->benchmark->elapsed_time();?>