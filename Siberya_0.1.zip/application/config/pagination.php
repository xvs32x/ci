<?php

$config['full_tag_open'] = '<div class="text-center"><ul class="pagination">';
$config['full_tag_close'] = '</ul></div>';

$config['num_tag_open'] = '<li>';
$config['num_tag_close'] = '</li>';

$config['cur_tag_open'] = '<li class="active" onclick="return false;"><a href="">';
$config['cur_tag_close'] = ' <span class="sr-only"></span></a></li>';

$config['prev_link'] = '&laquo;Назад';
$config['prev_tag_open'] = '<li>';
$config['prev_tag_close'] = '</li>';

$config['next_link'] = 'Далее&raquo;';
$config['next_tag_open'] = '<li>';
$config['next_tag_close'] = '</li>';

$config['last_link'] = 'Последняя';
$config['last_tag_open'] = '<li>';
$config['last_tag_close'] = '</li>';

$config['first_link'] = 'В начало';
$config['first_tag_open'] = '<li>';
$config['first_tag_close'] = '</li>';

$config['use_page_numbers'] = TRUE;