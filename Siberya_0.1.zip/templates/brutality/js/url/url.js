$(function(){
	$('.friendly_url').friendurl({id : 'friendly_url_title', divider: '_', transliterate: true});
});