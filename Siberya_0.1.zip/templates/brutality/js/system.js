$(function(){

	/*
	 * Fancybox
	 * */
	$('a.fancybox').fancybox({
		openEffect	: 'elastic',
		closeEffect	: 'elastic',
		loop: false
	});
 });